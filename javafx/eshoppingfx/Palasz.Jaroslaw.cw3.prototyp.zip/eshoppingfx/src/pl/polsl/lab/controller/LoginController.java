package pl.polsl.lab.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import pl.polsl.lab.MyException;

import java.io.IOException;
import java.util.Objects;


public class LoginController {
    @FXML
    private TextField textField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private Button loginButton;

    public TextField getTextField() { return textField; }

    public PasswordField getPasswordField() { return passwordField; }

    public Button getLoginButton() { return loginButton; }

    @FXML
    private void login(ActionEvent actionEvent){
        Parent root;
        try{
            /*try{

            }catch (MyException myException){

            }*/
            String username = textField.getText();
            String password = passwordField.getText();
            //TODO:check
            root = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource
                    ("pl/polsl/lab/view/category.fxml")));
            Stage stage = new Stage();
            stage.setTitle("CategoryView");
            stage.setScene(new Scene(root, 600, 600));
            stage.show();
        }
        catch (IOException exception){
            exception.printStackTrace();
        }
    }
}
