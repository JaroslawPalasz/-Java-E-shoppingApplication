package pl.polsl.lab.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class CategoryController {
    @FXML
    private Button backButton;
    @FXML
    private Button logoutButton;
    @FXML
    private Button category1Button;
    @FXML
    private Button category2Button;
    @FXML
    private Button category3Button;
    @FXML
    private Button category4Button;
    @FXML
    private Label loggedLabel;

    //TODO: handle all category and button clicks in 1 function?
    @FXML
    private void chooseCategory1(ActionEvent actionEvent){

        Parent root;
        try{
            root = FXMLLoader.load(Objects.requireNonNull(getClass().getClassLoader().getResource
                    ("pl/polsl/lab/view/productList.fxml")));
            Stage stage = new Stage();
            stage.setTitle("productListView");
            stage.setScene(new Scene(root, 600, 600));
            stage.show();
        }
        catch (IOException exception){
            exception.printStackTrace();
        }
    }
}
