package pl.polsl.lab.controller;

public class ProductListController {
}
